package com.datastructure.withtesting.queueArrayList;

public interface QueueArrayList<T> {
	
	void enQueue(T object);
	T deQueue();
	T peek();
	int getSize();
	boolean isEmpty();
}
