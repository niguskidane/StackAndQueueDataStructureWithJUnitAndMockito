package com.datastructure.withtesting.queueArrayList;

public class QueueImplArrayList implements QueueArrayList<Object> {

	private int front;
	private int end;
	private int size;
	private Object data[];

	public QueueImplArrayList() {
		this.front = -1;
		this.end = 0;
		this.size = 10;
		data = new Object[size];
	}

	public void enQueue(Object object) {
		if (isEmpty()) {
			front++;
			data[end] = object;
			end++;
		} else {
			data[end] = object;
			end++;
		}
	}

	public Object deQueue() {
		if (isEmpty() || data==null) {
			return "The Queue is Empity";
		}
		Object resultObject = data[front];
		front++;
		return resultObject;
	}

	public Object peek() {
		if (isEmpty()) {
			return "The Queue is Empity";
		}
		Object resultObject = data[front];
		return resultObject;
	}

	public int getSize() {
		if (isEmpty() ) {
			return 0;
		}
		return end - front;
	}

	public boolean isEmpty() {
		if (front == -1 || end == 0 || front>end) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer();

		for (int i = front; i < end; i++) {
			stringBuffer.append("[ " + data[i] + ", " + " ]");
		}
		return stringBuffer.toString();
	}

}
