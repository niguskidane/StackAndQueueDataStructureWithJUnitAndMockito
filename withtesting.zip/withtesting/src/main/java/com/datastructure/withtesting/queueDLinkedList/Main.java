package com.datastructure.withtesting.queueDLinkedList;

public class Main {

	public static void main(String[] args) {

		QueueImplDLL queue = new QueueImplDLL();
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Bob");
		queue.enQueue("Bob");
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);

		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Anna");
		queue.enQueue("Anna");
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Tisen");
		queue.enQueue("Tisen");
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Maclin");
		queue.enQueue("Maclin");

		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);

		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : " + queue.deQueue());
		System.out.println(queue);
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : " + queue.deQueue());
		System.out.println(queue);
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : " + queue.deQueue());
		System.out.println(queue);
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : " + queue.deQueue());
		System.out.println(queue);
		System.out.println("The queue Holds : " + queue.getSize() + " Number Of Element : " + queue);
		
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Maclin");
		queue.enQueue("Maclin");
		System.out.println("The queue Holds : "+queue.getSize()+ " Number Of Element : "+queue);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Tisen");
		queue.enQueue("Tisen");

		System.out.println("The queue Holds : "+queue.getSize()+ " Number Of Element : "+queue);
		
		System.out.println("Peeked : ------------------>>>>>>>>>>>>>>>>> : "+queue.peek());

		System.out.println("The queue Holds : "+queue.getSize()+ " Number Of Element : "+queue);
	}

}
