package com.datastructure.withtesting.queueDLinkedList;

public interface QueueDLinkedList<T> {
	void enQueue(T object);
	T deQueue();
	T peek();
	int getSize();
	boolean isEmpty();
}
