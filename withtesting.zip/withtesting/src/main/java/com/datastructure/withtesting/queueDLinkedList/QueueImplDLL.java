package com.datastructure.withtesting.queueDLinkedList;

public class QueueImplDLL implements QueueDLinkedList<Object> {

	Node<Object> header;

	public QueueImplDLL() {
		header = new Node<Object>(null, null, null);
	}

	public void enQueue(Object object) {
		Node<Object> newNode = new Node<Object>(object, header, header.next);
		if (isEmpty()) {
			header.next = newNode;
		} else if (header.next.next == null) {
			Node<Object> newNode0 = new Node<Object>(object, header.next, header.next.next);
			Node<Object> teNode = header.next;
			teNode.next = newNode0;
		} else {
			Node<Object> temp = header.next;
			Node<Object> lastNode = null;
			while (temp.next != null) {
				temp = temp.next;
				lastNode = temp;
			}
			Node<Object> newNode2 = new Node<Object>(object, lastNode, lastNode.next);
			lastNode.next = newNode2;
			newNode2.previous = lastNode;
		}
	}

	public Object deQueue() {
		if (isEmpty()) {
			return "The Queue is Empity";
		} else if (header.next.next == null) {
			Node<Object> result = header.next;
			header.next = null;
			return result.value;
		} else {
			Node<Object> result1 = header.next;
			result1.next.previous = header;
			result1.previous.next = result1.next;
			return result1.value;
		}
	}

	public Object peek() {
		if (isEmpty()) {
			return "The Queue is Empity";
		} else {
			Node<Object> result = header.next;
			return result.value;
		}
	}

	public int getSize() {
		if (isEmpty()) {
			return 0;
		} else {
			Node<Object> tempNode = header.next;
			int count = 0;
			while (tempNode != null) {
				tempNode = tempNode.next;
				count++;
			}
			return count;
		}
	}

	public boolean isEmpty() {
		if (header.next == null) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer();
		Node<Object> tempNode = header.next;

		while (tempNode != null) {
			stringBuffer.append("[ " + tempNode.value + ", " + " ]");
			tempNode = tempNode.next;
		}
		return stringBuffer.toString();
	}

	public static class Node<T> {
		T value;
		Node<T> previous;
		Node<T> next;

		public Node(T value, Node<T> previous, Node<T> next) {
			this.value = value;
			this.previous = previous;
			this.next = next;
		}

	}

}
