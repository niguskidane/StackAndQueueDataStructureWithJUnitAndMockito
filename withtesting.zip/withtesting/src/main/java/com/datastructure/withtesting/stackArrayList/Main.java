package com.datastructure.withtesting.stackArrayList;

public class Main {

	public static void main(String[] args) {
		StackImplArray stack= new StackImplArray();
		
		stack.push("Bob");
		stack.push("Anna");
		
		System.out.println(stack.toString());
		System.out.println(stack.getSize()==2);
		
		stack.pop();
		System.out.println(stack.toString());
		System.out.println(stack.getSize()==1);

	}

}
