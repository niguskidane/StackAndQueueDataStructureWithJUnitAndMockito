package com.datastructure.withtesting.stackArrayList;

public interface StackArrayList<T> {
	void push(T object);
	T pop();
	int getSize();
}
