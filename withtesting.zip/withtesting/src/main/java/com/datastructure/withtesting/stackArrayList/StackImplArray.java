package com.datastructure.withtesting.stackArrayList;

public class StackImplArray implements StackArrayList<Object> {
	
	private int start;
	private int size;
	private Object data[];
	
	public StackImplArray() {
		size=10;
		data=new Object[size];
	}
	
	public void push(Object object) {
		data[start]=object;
		start++;
	}
	
	public Object pop() {
		Object object=data[start];
		start--;
		return object;
	}
	
	public int getSize() {
		return this.start;
	}
	
	@Override
	public String toString() {
		StringBuffer stringBuffer=new StringBuffer();
		for(int i=0; i<start; i++) {
			stringBuffer.append(data[i]+", ");
		}
		return stringBuffer.toString();
	}

}
