package com.datastructure.withtesting.stackDLinkedList;

public class Main {

	public static void main(String[] args) {
		
		StackImplDLL stack=new StackImplDLL();
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Bob");
		stack.push("Bob");
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Anna");
		stack.push("Anna");
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Tisen");
		stack.push("Tisen");
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Maclin");
		stack.push("Maclin");
	
		
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : "+stack.pop());
		System.out.println(stack);
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : "+stack.pop());
		System.out.println(stack);
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : "+stack.pop());
		System.out.println(stack);
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Removed : ------------------>>>>>>>>>>>>>>>>> : "+stack.pop());
		System.out.println(stack);
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);

		
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Maclin");
		stack.push("Maclin");
		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		System.out.println("Adding : ------------------>>>>>>>>>>>>>>>>> : Tisen");
		stack.push("Tisen");

		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
		
		System.out.println("Peeked : ------------------>>>>>>>>>>>>>>>>> : "+stack.peek());

		System.out.println("The Stack Holds : "+stack.getSize()+ " Number Of Element : "+stack);
	}

}
