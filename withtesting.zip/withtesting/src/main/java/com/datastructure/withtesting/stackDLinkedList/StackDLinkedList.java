package com.datastructure.withtesting.stackDLinkedList;

public interface StackDLinkedList<T> {

	void push(T object);
	T pop();
	T peek();
	int getSize();
	boolean isEmpty();
}
