package com.datastructure.withtesting.stackDLinkedList;

public class StackImplDLL implements StackDLinkedList<Object> {

	private Node<Object> header;

	public StackImplDLL() {
		header = new Node<Object>(null, null, null);
	}

	public void push(Object object) {
		Node<Object> newNode = new Node<Object>(object, header, header.next);
		if (isEmpty()) {
			header.next = newNode;
		}else {
			header.next=newNode;
		}
	}

	public Object pop() {
		if (isEmpty()) {
			return "The Stack is Empty";
		}
		Node<Object> newNode=header.next;
		newNode.previous.next=newNode.next;
		return newNode.value;
	}

	public Object peek() {
		if (isEmpty()) {
			return "The Stack is Empty";
		}
		Node<Object> newNode=header.next;
		return newNode.value;
	}

	public int getSize() {
		if(isEmpty()) {
		    return 0;
		}else {
			Node<Object> tempNode = header.next;
			int count=0;
			while(tempNode!=null) {
				tempNode=tempNode.next;
				count++;
			}
			return count;
			
		}
	}

	public boolean isEmpty() {
		if (header.next == null) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer();
		Node<Object> tempNode = header.next;
		
		while(tempNode!=null) {
			stringBuffer.append("[ "+tempNode.value+", "+" ]");
			tempNode=tempNode.next;
		}
		return stringBuffer.toString();
	}

	public static class Node<T> {
		private T value;
		private Node<T> previous;
		private Node<T> next;

		public Node(T value, Node<T> previous, Node<T> next) {
			this.value = value;
			this.previous = previous;
			this.next = next;
		}
	}

}
