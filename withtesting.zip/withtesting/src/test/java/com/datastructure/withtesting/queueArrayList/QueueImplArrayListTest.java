package com.datastructure.withtesting.queueArrayList;

import junit.framework.TestCase;

public class QueueImplArrayListTest extends TestCase {

	private QueueImplArrayList queue;

	protected void setUp() throws Exception {
		queue = new QueueImplArrayList();
	}

	public void testEnQueue() {
		queue.enQueue("Bob");
		queue.enQueue("Anna");
		
		int expectedSize=2;
		int actualSize=queue.getSize();
		
		//Test
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		assertFalse(expectedSize!=actualSize);
	}

	public void testDeQueue() {
		queue.enQueue("Bob");
		queue.enQueue("Anna");
		queue.enQueue("Jhon");
		
		queue.deQueue();
		
		int expectedSize=2;
		int actualSize=queue.getSize();
		
		//Test
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		assertFalse(expectedSize!=actualSize);
		
		Object actualOutput=queue.deQueue();
		Object expectObject="Anna";
		
		//Test
		assertEquals(expectObject, actualOutput);
		assertTrue(actualOutput==expectObject);
		assertFalse(actualOutput!=expectObject);
	}

	public void testPeek() {
		queue.enQueue("Bob");
		queue.enQueue("Anna");
		
		Object expectedPeekedObject="Bob";
		Object actualPeekedObject=queue.peek();
		
		//Test
		assertEquals(expectedPeekedObject, actualPeekedObject);
		assertTrue(expectedPeekedObject==actualPeekedObject);
		assertFalse(expectedPeekedObject!=actualPeekedObject);
		
		assertTrue(expectedPeekedObject.equals(actualPeekedObject));
		assertFalse(!expectedPeekedObject.equals(actualPeekedObject));
	}

	public void testGetSize() {
		queue.enQueue("Bob");
		queue.enQueue("Anna");
		
		int expectedSize=2;
		int actualSize=queue.getSize();
		
		//Test
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		assertFalse(expectedSize!=actualSize);
	}

	public void testIsEmpty() {
		queue.enQueue("Bob");
		queue.enQueue("Anna");
		
		int expectedSize=2;
		int actualSize=queue.getSize();
		
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		
		queue.deQueue();
		queue.deQueue();
		
		int expectedSize1=0;
		int actualSize1=queue.getSize();
		
		assertEquals(expectedSize1, actualSize1);
		
		//Check this scenario
		
//		Object expectObject="The Queue is Empity";
//		Object actualObject=queue.deQueue();
//		System.out.println(actualObject);
//		assertTrue(expectObject.equals(actualObject));
	}
	
	protected void tearDown() throws Exception {
		queue = null;
	}

}
