package com.datastructure.withtesting.stackArrayList;

import com.datastructure.withtesting.stackArrayList.StackImplArray;

import junit.framework.TestCase;

public class StackImplArrayTest extends TestCase {

	private StackImplArray stack;

	protected void setUp() throws Exception {
		 stack= new StackImplArray();
	}
	
	public void testPush() {
		stack.push("Bob");
		stack.push("Anna");
		int actualSize=stack.getSize();
		int expectedSize=2;
		assertEquals(expectedSize, actualSize);
	}

	public void testPop() {
		stack.push("Bob");
		stack.push("Anna");
		stack.pop();
		int actualSize=stack.getSize();
		int expectedSize=1;
		assertEquals(expectedSize, actualSize);
	}
	

	public void testSize() {
		stack.push("Bob");
		stack.push("Anna");
		int actualSize=stack.getSize();
		int expectedSize=4;
		assertNotSame(expectedSize, actualSize);
		assertFalse(expectedSize==actualSize);
	}
	
	protected void tearDown() throws Exception {
		stack=null;
	}

}
