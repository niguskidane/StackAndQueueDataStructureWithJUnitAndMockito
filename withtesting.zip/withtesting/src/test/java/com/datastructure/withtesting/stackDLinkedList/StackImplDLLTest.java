package com.datastructure.withtesting.stackDLinkedList;

import junit.framework.TestCase;

public class StackImplDLLTest extends TestCase {

	StackImplDLL stack;

	protected void setUp() throws Exception {
		stack = new StackImplDLL();
	}

	public void testpush() {
		stack.push("Bob");
		stack.push("Anna");
		
		int expectedSize=2;
		int actualSize=stack.getSize();
		
		//Test
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		assertFalse(expectedSize!=actualSize);
	}

	public void testpop() {
		stack.push("Bob");
		stack.push("Anna");
		stack.push("Jhon");
		
		stack.pop();
		
		int expectedSize=2;
		int actualSize=stack.getSize();
		
		//Test
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		assertFalse(expectedSize!=actualSize);
		
		Object actualOutput=stack.pop();
		Object expectObject="Anna";
		
		//Test
		assertEquals(expectObject, actualOutput);
		assertTrue(actualOutput==expectObject);
		assertFalse(actualOutput!=expectObject);
	}

	public void testPeek() {
		stack.push("Bob");
		stack.push("Anna");
		
		Object expectedPeekedObject="Anna";
		Object actualPeekedObject=stack.peek();
		
		//Test
		assertEquals(expectedPeekedObject, actualPeekedObject);
		assertTrue(expectedPeekedObject==actualPeekedObject);
		assertFalse(expectedPeekedObject!=actualPeekedObject);
		
		assertTrue(expectedPeekedObject.equals(actualPeekedObject));
		assertFalse(!expectedPeekedObject.equals(actualPeekedObject));
	}

	public void testGetSize() {
		stack.push("Bob");
		stack.push("Anna");
		
		int expectedSize=2;
		int actualSize=stack.getSize();
		
		//Test
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		assertFalse(expectedSize!=actualSize);
	}

	public void testIsEmpty() {
		stack.push("Bob");
		stack.push("Anna");
		
		int expectedSize=2;
		int actualSize=stack.getSize();
		
		assertEquals(expectedSize, actualSize);
		assertTrue(expectedSize==actualSize);
		
		stack.pop();
		stack.pop();
		
		int expectedSize1=0;
		int actualSize1=stack.getSize();
		
		assertEquals(expectedSize1, actualSize1);
		
		Object expectObject="The Stack is Empty";
		Object actualObject=stack.pop();
		
		assertEquals(expectObject, actualObject);
	}
	
	protected void tearDown() throws Exception {
		stack=null;
	}

}
